sabre/cs
========

sabre/cs provides coding standards for all sabre packages.

This is a developer-only package, and only really interesting if you are
maintaining or creating sabre/* packages.


Installation
------------

Make sure you have [composer][1] installed, and then run:

    composer require sabre/cs


Build status
------------

| branch | status |
| ------ | ------ |
| master | [![Build Status](https://travis-ci.org/fruux/sabre-cs.png?branch=master)](https://travis-ci.org/fruux/sabre-cs) |


Questions?
----------

Head over to the [sabre/dav mailinglist][2], or you can also just open a ticket
on [GitHub][3].


Made at fruux
-------------

This package is being developed by [fruux][4]. Drop us a line for commercial
services or enterprise support.

[1]: http://getcomposer.org/
[2]: http://groups.google.com/group/sabredav-discuss
[3]: https://github.com/fruux/sabre-cs/issues/
[4]: https://fruux.com/
